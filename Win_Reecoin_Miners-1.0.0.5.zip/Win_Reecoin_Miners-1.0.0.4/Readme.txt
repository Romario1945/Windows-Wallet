
just open the Reecoin wallet.
Then start the scrypt: start_mining.sh.bat